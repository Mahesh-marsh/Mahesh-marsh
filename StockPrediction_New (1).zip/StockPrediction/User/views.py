from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User, auth
import pandas as pd
from sklearn.tree import DecisionTreeRegressor
from django.core.mail import send_mail
import math
import random

otp = None
def otpGen(request):
	string = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
	OTP = ''
	for i in range(6):
		OTP += string[math.floor(random.random() * len(string))]
	return OTP

def otpSend(request,user,otp):
    emailto = user.email
    if emailto:
    	send_mail(
			"OTP",
			"Your OTP is "+otp+". Do not share it with anyone by any means. This is confidential and to be used by you only.",
			'admin@no-reply.com',
			[emailto],
			fail_silently=False,
			)

def otpVerify(request):
	global otp
	user = request.user
	if otp == None:
		otp = otpGen(request)
		otpSend(request,user,otp)
		return render(request,'otp.html')
	else:
		if request.method == "POST":
			otpfield = request.POST['otp']
			if otpfield == otp:
				return redirect('data')
			else:
				auth.logout(request)
				return render(request,'index.html')
		else:
			otp = otpGen(request)
			otpSend(request,user,otp)
			auth.logout(request)
			return render(request,'otp.html')

def index(request):
    return render(request,"index.html")

def login(request):
    if request.method == 'POST':
        #v = DoctorReg.objects.all()
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            return redirect('data')
        else:
            messages.info(request, 'Invalid credentials')
            return render(request,'login.html')
    else:
        return render(request, 'login.html')


def register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password = request.POST['password']
        password2= request.POST['password2']
        email = request.POST['email']

        if password == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'Username is already exist')
                return render(request,'register.html')
            elif User.objects.filter(email=email).exists():
                messages.info(request, 'Email is already exist')
                return render(request,'register.html')
            else:

                #save data in db
                user = User.objects.create_user(username=username, password=password, email=email,
                                                first_name=first_name, last_name=last_name)
                user.save();
                print('user created')
                return redirect('login')

        else:
            messages.info(request, 'Invalid Credentials')
            return render(request,'register.html')
        return redirect('/')
    else:
        return render(request, 'register.html')

def data(request):
    return render(request,"data.html")


def predict(request):
    if (request.method == 'POST'):
        open = request.POST['open']
        high = request.POST['high']
        low= request.POST['low']
        last = request.POST['last']
        close = request.POST['close']
        trade=request.POST['trade']

        df = pd.read_csv(r"static/datasets/Stock.csv")
        df.dropna(inplace=True)
        df.isnull().sum()
        
    #group by ICU admission
        #ICU_prop_main = ICU_prop.groupby('ICU')['PATIENT_VISIT_IDENTIFIER'].count().reset_index()
        import matplotlib.pyplot as plt
        
        plt.title('Stock Market Data')
        plt.scatter(df['Last'],df['Turnover (Lacs)'])
        plt.show()
        plt.bar(df['Open'],df['Close'])
        plt.show()
        
        
        plt.plot(df['Last'],df['Turnover (Lacs)'])
        plt.show()
        X_train = df[['Open','High','Low','Last','Close','Total Trade Quantity']]

        Y_train = df[['Turnover (Lacs)']]
        tree = DecisionTreeRegressor()
        tree.fit(X_train, Y_train)

        

        prediction = tree.predict([[open,high,low,last,close,trade]])
        from sklearn.model_selection import train_test_split
        x=df.drop('Turnover (Lacs)',axis=1)
        y=df['Turnover (Lacs)']
        x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.34)
        tree.fit(x_train,y_train)
        pred=tree.predict(x_test)
        plt.title("Predicted Data")
        plt.plot(x_test,pred)
        plt.show()
        

        #stock=StockData.objects.create(Open_Year=open,Last_Year=last,High_Profit=high,Low_Profit=low,Trade_Amt=trade)
        #stock.save()
        return render(request, 'predict.html',
                      {"data": prediction, 'open': open,  'high': high,
                       'close': close, 'last': last,"low":low,'trade':trade
                       })
    else:
        return render(request, 'predict.html')

def logout(request):
    return render(request,"logout.html")