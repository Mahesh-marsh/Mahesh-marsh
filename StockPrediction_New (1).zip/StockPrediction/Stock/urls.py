from django.urls import path
from .import views

urlpatterns=[
    path('home',views.home,name='index'),
    path('register1',views.register1,name='register'),
    #path('stock/login1',views.login1,name='login'),
    path('data',views.stock,name='stock'),
    path('user',views.userstock,name='ustock'),
    #path('user',views.user,name='user')

]
