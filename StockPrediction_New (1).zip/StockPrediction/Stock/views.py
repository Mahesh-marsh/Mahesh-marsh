from django.shortcuts import render, redirect
#from .models import DoctorReg, predictions, Regdb
from django.contrib import messages
from django.contrib.auth.models import User, auth
import pandas as pd
from .models import StockData
from User.models import Stock
from .models import StockUser

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor


# Create your views here.

def home(request):
    if request.method == 'POST':

        username = request.POST['username']
        password = request.POST['password']

        suser = auth.authenticate(username=username, password=password)

        if suser is not None:
            auth.login(request, suser)
            return render(request,"stock.html")
        else:
            messages.info(request, 'Invalid credentials')
            return render(request,"home.html")
    else:
        return render(request, 'home.html')



def register1(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']

        if password1 == password2:
            if StockUser.objects.filter(username=username).exists():
                messages.info(request, 'Username Taken')
                return render(request,"register1.html")
            elif StockUser.objects.filter(email=email).exists():
                messages.info(request, 'Email Taken')
                return render(request,"register1.html")
            else:
                suser = StockUser.objects.create(username=username, password=password1, email=email,
                                                first_name=first_name, last_name=last_name)
                suser.save();
                print('user created')
                return render(request,'home.html')

        else:
            messages.info(request, 'Password not matching')
            return render(request,"register1.html")
        return redirect('home')
    else:
        return render(request, 'register1.html')


"""
def login1(request):
    if request.method == 'POST':

        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            return render(request,"stock.html")
        else:
            messages.info(request, 'Invalid credentials')
            return render(request,"home.html")
    else:
        return render(request, 'login1.html')"""

def stock(request):
    s=StockData.objects.all()
    return render(request,'stock.html',{"s":s})
def logout(request):
    return render(request,"logout.html")
def userstock(request):
    #username = request.POST['username']
    #suser = StockUser.objects.filter(username=username) == 0:
    suser=StockUser.objects.filter(id=3)
    return render(request,"userstock.html",{"suser":suser})

"""def user(request):
    #global loginFlag, loginUser
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        print(username)
        message = ""

        if len(StockUser.objects.filter(username=username)) == 0:
            message = message + "No Matching Accounts Found"
        else:
            suser = StockUser.objects.get(username=username)
            print(StockUser.email)
            print(message)
            context = {"suser": suser}
            return render(request, 'home.html',context)




    else:
        return render(request, 'stock.html')"""